@echo off
title Aether Frame Windows Builder
cd /d "%~dp0"
call npm install
if errorlevel 1 goto :failed
call npm run dist:win
if errorlevel 1 goto :failed
echo.
echo Build complete. Open the release folder to find the installer and portable EXE.
pause
exit /b
:failed
echo.
echo Build failed. Review the error above.
pause
