# Aether Frame

Aether Frame is a Windows desktop spatial-canvas experiment controlled by a webcam and two hands. It is an original interface concept, not a clone of Iron Man or any existing product.

## What it does

- Tracks up to two hands locally with MediaPipe.
- Creates rectangles by pinching thumb + index finger on both hands.
- Resizes the live frame while both pinches remain held.
- Places the frame when the pinch is released.
- Moves a panel with a one-hand pinch inside it.
- Resizes a panel by pinching near one of its four corners.
- Offers a mouse mode: choose Panel or Square, then click and drag.
- Renders the visual layer at the monitor refresh rate, with AI inference on a separate adaptive loop.
- Works offline after installation; camera images are not uploaded.

## Quick start in VS Code

Requirements: Windows 10/11, Node.js 20 or newer, and a webcam.

1. Extract the ZIP and open the folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Run:

   ```bash
   npm install
   npm run desktop
   ```

4. Click **Initialize Vision** and allow camera permission.

You can also double-click `START-AETHER-FRAME.bat` after `npm install` has completed once.

## Build a Windows installer

In the VS Code terminal run:

```bash
npm install
npm run dist:win
```

The Windows installer and portable `.exe` will be created inside the `release` folder.

## Gestures

| Gesture | Action |
| --- | --- |
| Thumb + index pinch on both hands | Create and scale a panel |
| Release either pinch | Place the panel |
| One-hand pinch inside a panel | Move the panel |
| One-hand pinch near a corner | Resize the panel |

For reliable tracking, keep both hands inside the camera frame, face your palms toward the camera, and use even front lighting.

## Performance note

The renderer targets 60 FPS. Actual FPS and tracking latency depend on the webcam, lighting, processor, background apps, and display refresh rate. The telemetry panel shows live measured values.
