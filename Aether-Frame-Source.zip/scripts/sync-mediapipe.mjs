import { cp, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const source = resolve(root, 'node_modules/@mediapipe/hands');
const target = resolve(root, 'public/mediapipe');

if (!existsSync(source)) {
  console.warn('MediaPipe package is not installed yet; skipping asset sync.');
  process.exit(0);
}

await mkdir(target, { recursive: true });
await cp(source, target, { recursive: true, force: true });
console.log('MediaPipe hand-tracking assets synced for offline use.');
