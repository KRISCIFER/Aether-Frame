import './style.css';

const $ = (selector) => document.querySelector(selector);
const canvas = $('#stage');
const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
const video = $('#camera');

const ui = {
  welcome: $('#welcome'), error: $('#permissionError'), errorText: $('#errorText'),
  toast: $('#toast'), fps: $('#fpsValue'), hands: $('#handValue'), latency: $('#latencyValue'),
  camera: $('#cameraStatus'), engine: $('#engineStatus'), count: $('#objectCount'),
  trackingDot: $('#trackingDot'), trackingLabel: $('#trackingLabel'), signal: $('.signal'),
  cameraToggle: $('#cameraToggle'), selectionBar: $('#selectionBar'), selectionName: $('#selectionName')
};

const state = {
  width: innerWidth, height: innerHeight, dpr: 1,
  cameraOn: false, detecting: false, detector: null, lastInference: 0,
  hands: [], handHistory: [[], []], inferenceLatency: 0,
  shapes: [], selectedId: null, preview: null, interaction: null,
  dualActive: false, singleWasPinched: false, mouseDown: false,
  tool: 'select', mirror: true, trails: true, frame: 0,
  fps: 60, fpsFrames: 0, fpsStarted: performance.now(), undo: [],
  toastTimer: 0
};

const HAND_CONNECTIONS = [
  [0,1],[1,2],[2,3],[3,4], [0,5],[5,6],[6,7],[7,8],
  [5,9],[9,10],[10,11],[11,12], [9,13],[13,14],[14,15],[15,16],
  [13,17],[17,18],[18,19],[19,20],[0,17]
];

function resize() {
  state.width = innerWidth;
  state.height = innerHeight;
  state.dpr = Math.min(devicePixelRatio || 1, 1.75);
  canvas.width = Math.round(state.width * state.dpr);
  canvas.height = Math.round(state.height * state.dpr);
  canvas.style.width = `${state.width}px`;
  canvas.style.height = `${state.height}px`;
  ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
}

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const lerp = (a, b, t) => a + (b - a) * t;
const uid = () => crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;

function normalizedRect(a, b, lockSquare = false) {
  let dx = b.x - a.x;
  let dy = b.y - a.y;
  if (lockSquare) {
    const size = Math.max(Math.abs(dx), Math.abs(dy));
    dx = Math.sign(dx || 1) * size;
    dy = Math.sign(dy || 1) * size;
  }
  const x = Math.min(a.x, a.x + dx);
  const y = Math.min(a.y, a.y + dy);
  return { x, y, w: Math.abs(dx), h: Math.abs(dy) };
}

function snapshot() {
  state.undo.push(JSON.stringify(state.shapes));
  if (state.undo.length > 40) state.undo.shift();
}

function undo() {
  const previous = state.undo.pop();
  if (!previous) return notify('NOTHING TO UNDO');
  state.shapes = JSON.parse(previous);
  state.selectedId = null;
  updateObjectUi();
  notify('ACTION REVERSED');
}

function notify(message) {
  clearTimeout(state.toastTimer);
  ui.toast.textContent = message;
  ui.toast.classList.add('show');
  state.toastTimer = setTimeout(() => ui.toast.classList.remove('show'), 1400);
}

function updateObjectUi() {
  ui.count.textContent = String(state.shapes.length).padStart(2, '0');
  const index = state.shapes.findIndex((shape) => shape.id === state.selectedId);
  ui.selectionBar.classList.toggle('hidden', index < 0);
  if (index >= 0) ui.selectionName.textContent = `PANEL ${String(index + 1).padStart(2, '0')}`;
}

function addShape(rect) {
  if (rect.w < 52 || rect.h < 52) return notify('FRAME TOO SMALL');
  snapshot();
  const shape = { ...rect, id: uid(), created: performance.now(), hue: state.shapes.length % 2 ? 'violet' : 'cyan' };
  state.shapes.push(shape);
  state.selectedId = shape.id;
  state.preview = null;
  updateObjectUi();
  notify('HOLOGRAPHIC PANEL CREATED');
}

function selectedShape() { return state.shapes.find((shape) => shape.id === state.selectedId); }

function deleteSelected() {
  if (!state.selectedId) return notify('SELECT A PANEL');
  snapshot();
  state.shapes = state.shapes.filter((shape) => shape.id !== state.selectedId);
  state.selectedId = null;
  updateObjectUi();
  notify('PANEL REMOVED');
}

function clearShapes() {
  if (!state.shapes.length) return notify('CANVAS ALREADY CLEAR');
  snapshot();
  state.shapes = [];
  state.selectedId = null;
  updateObjectUi();
  notify('SPATIAL CANVAS CLEARED');
}

function corners(shape) {
  return [
    { x: shape.x, y: shape.y, key: 'nw' }, { x: shape.x + shape.w, y: shape.y, key: 'ne' },
    { x: shape.x + shape.w, y: shape.y + shape.h, key: 'se' }, { x: shape.x, y: shape.y + shape.h, key: 'sw' }
  ];
}

function hitTest(point) {
  for (let i = state.shapes.length - 1; i >= 0; i--) {
    const shape = state.shapes[i];
    const corner = corners(shape).find((c) => dist(c, point) < 38);
    if (corner) return { shape, type: 'resize', corner: corner.key };
    if (point.x >= shape.x && point.x <= shape.x + shape.w && point.y >= shape.y && point.y <= shape.y + shape.h) {
      return { shape, type: 'move' };
    }
  }
  return null;
}

function beginInteraction(point, allowCreate = true) {
  const hit = hitTest(point);
  if (hit) {
    snapshot();
    state.selectedId = hit.shape.id;
    state.interaction = {
      type: hit.type, id: hit.shape.id, corner: hit.corner,
      start: point, original: { x: hit.shape.x, y: hit.shape.y, w: hit.shape.w, h: hit.shape.h }
    };
    updateObjectUi();
  } else if (allowCreate && state.tool !== 'select') {
    state.selectedId = null;
    state.interaction = { type: 'create', start: point };
    state.preview = { x: point.x, y: point.y, w: 0, h: 0 };
    updateObjectUi();
  } else {
    state.selectedId = null;
    updateObjectUi();
  }
}

function updateInteraction(point) {
  const op = state.interaction;
  if (!op) return;
  if (op.type === 'create') {
    state.preview = normalizedRect(op.start, point, state.tool === 'square');
    return;
  }
  const shape = state.shapes.find((item) => item.id === op.id);
  if (!shape) return;
  if (op.type === 'move') {
    shape.x = clamp(op.original.x + point.x - op.start.x, 16, state.width - shape.w - 16);
    shape.y = clamp(op.original.y + point.y - op.start.y, 72, state.height - shape.h - 72);
    return;
  }
  const opposite = {
    nw: { x: op.original.x + op.original.w, y: op.original.y + op.original.h },
    ne: { x: op.original.x, y: op.original.y + op.original.h },
    se: { x: op.original.x, y: op.original.y },
    sw: { x: op.original.x + op.original.w, y: op.original.y }
  }[op.corner];
  Object.assign(shape, normalizedRect(opposite, point, false));
}

function endInteraction() {
  if (state.interaction?.type === 'create' && state.preview) addShape(state.preview);
  state.interaction = null;
  state.preview = null;
}

function screenPoint(landmark) {
  return {
    x: (state.mirror ? 1 - landmark.x : landmark.x) * state.width,
    y: landmark.y * state.height,
    z: landmark.z || 0
  };
}

function smoothPoint(next, previous, amount = .52) {
  if (!previous) return next;
  return { x: lerp(previous.x, next.x, amount), y: lerp(previous.y, next.y, amount), z: lerp(previous.z || 0, next.z || 0, amount) };
}

function analyzeHand(landmarks, index) {
  const raw = landmarks.map(screenPoint);
  const old = state.hands[index]?.points;
  const points = raw.map((point, i) => smoothPoint(point, old?.[i], i === 4 || i === 8 ? .62 : .48));
  const palm = Math.max(dist(points[0], points[9]), 35);
  const pinchRatio = dist(points[4], points[8]) / palm;
  const pinched = pinchRatio < .42;
  const pinch = { x: (points[4].x + points[8].x) / 2, y: (points[4].y + points[8].y) / 2 };
  return { points, pinch, pinched, strength: clamp(1 - pinchRatio / .7, 0, 1) };
}

function handleGestures() {
  const hands = state.hands;
  const pinched = hands.filter((hand) => hand.pinched);

  if (hands.length >= 2 && hands[0].pinched && hands[1].pinched) {
    if (!state.dualActive) {
      state.dualActive = true;
      state.interaction = null;
      state.selectedId = null;
      updateObjectUi();
    }
    state.preview = normalizedRect(hands[0].pinch, hands[1].pinch, state.tool === 'square');
    state.singleWasPinched = false;
    return;
  }

  if (state.dualActive) {
    state.dualActive = false;
    if (state.preview) addShape(state.preview);
    state.preview = null;
  }

  if (pinched.length === 1) {
    const point = pinched[0].pinch;
    if (!state.singleWasPinched) beginInteraction(point, false);
    updateInteraction(point);
    state.singleWasPinched = true;
  } else if (state.singleWasPinched) {
    endInteraction();
    state.singleWasPinched = false;
  }
}

function onHandResults(results) {
  state.inferenceLatency = Math.round(performance.now() - state.inferenceStarted);
  let hands = (results.multiHandLandmarks || []).map((landmarks, index) => analyzeHand(landmarks, index));
  hands.sort((a, b) => a.pinch.x - b.pinch.x);
  state.hands = hands;
  if (state.trails) {
    hands.forEach((hand, index) => {
      state.handHistory[index].push({ ...hand.pinch, life: 1 });
      if (state.handHistory[index].length > 16) state.handHistory[index].shift();
    });
  }
  handleGestures();
}

async function startCamera() {
  ui.error.classList.add('hidden');
  ui.welcome.classList.add('hidden');
  ui.camera.textContent = 'LINKING';
  ui.engine.textContent = 'LOADING AI';
  try {
    if (!window.Hands) throw new Error('Hand-tracking files are missing. Run npm install once, then restart the app.');
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 60, min: 30 }, facingMode: 'user' },
      audio: false
    });
    video.srcObject = stream;
    await video.play();

    if (!state.detector) {
      state.detector = new window.Hands({
        locateFile: (file) => new URL(`./mediapipe/${file}`, location.href).href
      });
      state.detector.setOptions({
        maxNumHands: 2,
        modelComplexity: 1,
        minDetectionConfidence: .62,
        minTrackingConfidence: .56,
        selfieMode: false
      });
      state.detector.onResults(onHandResults);
    }

    state.cameraOn = true;
    ui.camera.textContent = '60 FPS LINK';
    ui.engine.textContent = 'TRACKING';
    ui.cameraToggle.textContent = 'STOP CAMERA';
    ui.trackingLabel.textContent = 'SPATIAL TRACKING LIVE';
    ui.trackingDot.classList.add('live');
    ui.signal.classList.add('active');
    detectLoop();
    notify('VISION ENGINE ONLINE');
  } catch (error) {
    state.cameraOn = false;
    ui.camera.textContent = 'OFFLINE';
    ui.engine.textContent = 'FAULT';
    ui.errorText.textContent = error?.message || 'Allow camera access in Windows privacy settings and try again.';
    ui.error.classList.remove('hidden');
  }
}

function stopCamera() {
  state.cameraOn = false;
  video.srcObject?.getTracks().forEach((track) => track.stop());
  video.srcObject = null;
  state.hands = [];
  state.handHistory = [[], []];
  ui.camera.textContent = 'OFFLINE';
  ui.engine.textContent = 'MOUSE MODE';
  ui.cameraToggle.textContent = 'START CAMERA';
  ui.trackingLabel.textContent = 'MANUAL CANVAS MODE';
  ui.trackingDot.classList.remove('live');
  ui.signal.classList.remove('active');
  notify('CAMERA DISCONNECTED');
}

function detectLoop(time = performance.now()) {
  if (!state.cameraOn) return;
  requestAnimationFrame(detectLoop);
  if (state.detecting || video.readyState < 2 || time - state.lastInference < 30) return;
  state.lastInference = time;
  state.detecting = true;
  state.inferenceStarted = performance.now();
  state.detector.send({ image: video }).catch((error) => {
    console.error(error);
    ui.engine.textContent = 'RECOVERING';
  }).finally(() => { state.detecting = false; });
}

function drawCamera() {
  const w = state.width, h = state.height;
  if (!state.cameraOn || video.readyState < 2) {
    const bg = ctx.createRadialGradient(w * .5, h * .45, 0, w * .5, h * .45, Math.max(w, h) * .7);
    bg.addColorStop(0, '#0b1820'); bg.addColorStop(.5, '#050c11'); bg.addColorStop(1, '#020507');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
    return;
  }
  const scale = Math.max(w / video.videoWidth, h / video.videoHeight);
  const dw = video.videoWidth * scale, dh = video.videoHeight * scale;
  const x = (w - dw) / 2, y = (h - dh) / 2;
  ctx.save();
  if (state.mirror) { ctx.translate(w, 0); ctx.scale(-1, 1); ctx.drawImage(video, w - x - dw, y, dw, dh); }
  else ctx.drawImage(video, x, y, dw, dh);
  ctx.restore();
  ctx.fillStyle = 'rgba(1,8,12,.32)'; ctx.fillRect(0, 0, w, h);
  const grade = ctx.createLinearGradient(0, 0, w, h);
  grade.addColorStop(0, 'rgba(4,49,58,.20)'); grade.addColorStop(.5, 'rgba(0,0,0,.02)'); grade.addColorStop(1, 'rgba(46,19,74,.18)');
  ctx.fillStyle = grade; ctx.fillRect(0, 0, w, h);
}

function drawGrid() {
  const w = state.width, h = state.height;
  ctx.save();
  ctx.strokeStyle = 'rgba(84,224,244,.055)'; ctx.lineWidth = 1;
  const horizon = h * .56;
  for (let x = -w; x < w * 2; x += 78) {
    ctx.beginPath(); ctx.moveTo(w / 2 + (x - w / 2) * .12, horizon); ctx.lineTo(x, h); ctx.stroke();
  }
  for (let y = horizon; y < h; y += Math.max(12, (y - horizon) * .2)) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  ctx.globalAlpha = .22;
  const scanY = (state.frame * .35) % h;
  const scan = ctx.createLinearGradient(0, scanY - 35, 0, scanY + 35);
  scan.addColorStop(0, 'rgba(95,246,255,0)'); scan.addColorStop(.5, 'rgba(95,246,255,.12)'); scan.addColorStop(1, 'rgba(95,246,255,0)');
  ctx.fillStyle = scan; ctx.fillRect(0, scanY - 35, w, 70);
  ctx.restore();
}

function roundedRectPath(x, y, w, h, r = 8) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, radius);
}

function drawPanel(shape, selected = false, preview = false) {
  const { x, y, w, h } = shape;
  if (w < 1 || h < 1) return;
  const violet = shape.hue === 'violet';
  const color = violet ? '167,123,255' : '95,246,255';
  ctx.save();
  ctx.shadowColor = `rgba(${color},.72)`;
  ctx.shadowBlur = preview ? 26 : selected ? 20 : 11;
  const fill = ctx.createLinearGradient(x, y, x + w, y + h);
  fill.addColorStop(0, `rgba(${color},.14)`); fill.addColorStop(.5, 'rgba(7,18,25,.20)'); fill.addColorStop(1, `rgba(${color},.045)`);
  roundedRectPath(x, y, w, h, 7);
  ctx.fillStyle = fill; ctx.fill();
  ctx.setLineDash(preview ? [9, 7] : []);
  ctx.lineWidth = selected || preview ? 1.6 : 1;
  ctx.strokeStyle = `rgba(${color},${selected || preview ? .88 : .48})`; ctx.stroke();
  ctx.setLineDash([]); ctx.shadowBlur = 0;

  ctx.strokeStyle = `rgba(${color},.13)`; ctx.lineWidth = 1;
  for (let gx = x + 28; gx < x + w; gx += 28) { ctx.beginPath(); ctx.moveTo(gx, y); ctx.lineTo(gx, y + h); ctx.stroke(); }
  for (let gy = y + 28; gy < y + h; gy += 28) { ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x + w, gy); ctx.stroke(); }

  const header = Math.min(31, h * .2);
  ctx.fillStyle = `rgba(${color},.055)`; ctx.fillRect(x, y, w, header);
  ctx.strokeStyle = `rgba(${color},.22)`; ctx.beginPath(); ctx.moveTo(x, y + header); ctx.lineTo(x + w, y + header); ctx.stroke();
  ctx.fillStyle = `rgba(${color},.72)`; ctx.font = '700 8px monospace';
  ctx.fillText(preview ? 'GENERATING FRAME' : 'AETHER OBJECT', x + 11, y + Math.min(19, header - 8));
  ctx.fillStyle = `rgba(${color},.35)`; ctx.textAlign = 'right';
  ctx.fillText(`${Math.round(w)} × ${Math.round(h)}`, x + w - 10, y + Math.min(19, header - 8));
  ctx.textAlign = 'left';

  const size = selected || preview ? 12 : 7;
  corners(shape).forEach((corner) => {
    ctx.strokeStyle = `rgba(${color},.95)`; ctx.lineWidth = 2;
    const sx = corner.key.includes('e') ? -1 : 1;
    const sy = corner.key.includes('s') ? -1 : 1;
    ctx.beginPath(); ctx.moveTo(corner.x, corner.y + sy * size); ctx.lineTo(corner.x, corner.y); ctx.lineTo(corner.x + sx * size, corner.y); ctx.stroke();
    if (selected) { ctx.fillStyle = '#eaffff'; ctx.fillRect(corner.x - 2, corner.y - 2, 4, 4); }
  });
  ctx.restore();
}

function drawHands() {
  if (state.trails) {
    state.handHistory.forEach((trail, handIndex) => {
      trail.forEach((point, index) => {
        point.life *= .93;
        ctx.fillStyle = `rgba(${handIndex ? '167,123,255' : '95,246,255'},${point.life * index / Math.max(1, trail.length) * .26})`;
        ctx.beginPath(); ctx.arc(point.x, point.y, 2 + index * .12, 0, Math.PI * 2); ctx.fill();
      });
    });
  }
  state.hands.forEach((hand, index) => {
    const rgb = index ? '167,123,255' : '95,246,255';
    ctx.save(); ctx.lineWidth = 1.25; ctx.strokeStyle = `rgba(${rgb},.48)`;
    ctx.shadowColor = `rgb(${rgb})`; ctx.shadowBlur = 8;
    HAND_CONNECTIONS.forEach(([a, b]) => {
      ctx.beginPath(); ctx.moveTo(hand.points[a].x, hand.points[a].y); ctx.lineTo(hand.points[b].x, hand.points[b].y); ctx.stroke();
    });
    ctx.shadowBlur = 4;
    hand.points.forEach((point, pointIndex) => {
      ctx.fillStyle = pointIndex === 4 || pointIndex === 8 ? '#eaffff' : `rgba(${rgb},.75)`;
      ctx.beginPath(); ctx.arc(point.x, point.y, pointIndex === 4 || pointIndex === 8 ? 3.2 : 1.8, 0, Math.PI * 2); ctx.fill();
    });
    const radius = hand.pinched ? 18 + Math.sin(state.frame * .12) * 2 : 12;
    ctx.shadowBlur = hand.pinched ? 22 : 8;
    ctx.strokeStyle = `rgba(${rgb},${hand.pinched ? .95 : .42})`; ctx.lineWidth = hand.pinched ? 2 : 1;
    ctx.beginPath(); ctx.arc(hand.pinch.x, hand.pinch.y, radius, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(hand.pinch.x, hand.pinch.y, 4, 0, Math.PI * 2); ctx.stroke();
    if (hand.pinched) {
      ctx.fillStyle = `rgba(${rgb},.85)`; ctx.font = '700 8px monospace';
      ctx.fillText(index ? 'GRIP B' : 'GRIP A', hand.pinch.x + 24, hand.pinch.y - 8);
    }
    ctx.restore();
  });
}

function render(now) {
  requestAnimationFrame(render);
  state.frame++;
  state.fpsFrames++;
  if (now - state.fpsStarted >= 500) {
    state.fps = Math.round(state.fpsFrames * 1000 / (now - state.fpsStarted));
    state.fpsFrames = 0; state.fpsStarted = now;
    ui.fps.textContent = state.fps;
    ui.hands.textContent = state.hands.length;
    ui.latency.textContent = state.cameraOn ? state.inferenceLatency : '--';
    [...ui.signal.children].forEach((bar, index) => {
      bar.style.height = state.cameraOn ? `${22 + ((state.inferenceLatency * (index + 3) * 7) % 68)}%` : '25%';
    });
  }
  ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
  drawCamera();
  drawGrid();
  state.shapes.forEach((shape) => drawPanel(shape, shape.id === state.selectedId));
  if (state.preview) drawPanel({ ...state.preview, hue: 'cyan' }, false, true);
  drawHands();
}

canvas.addEventListener('pointerdown', (event) => {
  state.mouseDown = true;
  canvas.setPointerCapture(event.pointerId);
  beginInteraction({ x: event.clientX, y: event.clientY }, true);
});
canvas.addEventListener('pointermove', (event) => {
  if (state.mouseDown) updateInteraction({ x: event.clientX, y: event.clientY });
});
canvas.addEventListener('pointerup', () => { state.mouseDown = false; endInteraction(); });
canvas.addEventListener('pointercancel', () => { state.mouseDown = false; endInteraction(); });

$('#startBtn').addEventListener('click', startCamera);
$('#retryBtn').addEventListener('click', startCamera);
$('#demoBtn').addEventListener('click', () => {
  ui.welcome.classList.add('hidden');
  ui.engine.textContent = 'MOUSE MODE';
  ui.trackingLabel.textContent = 'MANUAL CANVAS MODE';
  state.tool = 'panel';
  document.querySelectorAll('.tool[data-tool]').forEach((button) => button.classList.toggle('active', button.dataset.tool === 'panel'));
  notify('DRAG TO CREATE A PANEL');
});
ui.cameraToggle.addEventListener('click', () => state.cameraOn ? stopCamera() : startCamera());
$('#undoBtn').addEventListener('click', undo);
$('#deleteBtn').addEventListener('click', deleteSelected);
$('#clearBtn').addEventListener('click', clearShapes);
$('#mirrorToggle').addEventListener('change', (event) => { state.mirror = event.target.checked; });
$('#trailToggle').addEventListener('change', (event) => { state.trails = event.target.checked; if (!state.trails) state.handHistory = [[], []]; });

document.querySelectorAll('.tool[data-tool]').forEach((button) => {
  button.addEventListener('click', () => {
    state.tool = button.dataset.tool;
    document.querySelectorAll('.tool[data-tool]').forEach((item) => item.classList.toggle('active', item === button));
    notify(`${state.tool.toUpperCase()} TOOL ACTIVE`);
  });
});

ui.selectionBar.addEventListener('click', (event) => {
  const action = event.target.dataset.action;
  const shape = selectedShape();
  if (!action || !shape) return;
  if (action === 'delete') deleteSelected();
  if (action === 'duplicate') {
    snapshot();
    const copy = { ...shape, id: uid(), x: clamp(shape.x + 28, 10, state.width - shape.w), y: clamp(shape.y + 28, 70, state.height - shape.h), created: performance.now() };
    state.shapes.push(copy); state.selectedId = copy.id; updateObjectUi(); notify('PANEL DUPLICATED');
  }
  if (action === 'square') {
    snapshot(); const size = Math.max(shape.w, shape.h); shape.w = size; shape.h = size; notify('SQUARE RATIO LOCKED');
  }
});

$('#minimizeBtn').addEventListener('click', () => window.desktop?.minimize());
$('#closeBtn').addEventListener('click', () => window.desktop?.close());
$('#fullscreenBtn').addEventListener('click', async () => {
  if (window.desktop) await window.desktop.toggleFullscreen();
  else if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
  else await document.exitFullscreen();
});

addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); undo(); }
  else if (event.key === 'Delete' || event.key === 'Backspace') deleteSelected();
  else if (event.key.toLowerCase() === 'f') $('#fullscreenBtn').click();
  else if (event.key === 'Escape') { state.selectedId = null; state.preview = null; state.interaction = null; updateObjectUi(); }
});

addEventListener('resize', resize);
resize();
requestAnimationFrame(render);
