@echo off
title Aether Frame Launcher
cd /d "%~dp0"
if not exist "node_modules" (
  echo First launch: installing the required local packages...
  call npm install
  if errorlevel 1 goto :failed
)
call npm run desktop
exit /b
:failed
echo.
echo Installation failed. Check your internet connection and Node.js installation.
pause
