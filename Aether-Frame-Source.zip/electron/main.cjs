const { app, BrowserWindow, ipcMain, session, protocol, net } = require('electron');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

let mainWindow;

protocol.registerSchemesAsPrivileged([{
  scheme: 'aether',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true }
}]);

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: '#030609',
    titleBarStyle: 'hidden',
    titleBarOverlay: false,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.removeMenu();
  mainWindow.once('ready-to-show', () => mainWindow.show());

  if (process.env.VITE_DEV_SERVER_URL) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else if (!app.isPackaged) {
    mainWindow.loadURL('http://127.0.0.1:5173');
  } else {
    mainWindow.loadURL('aether://app/index.html');
  }
}

app.whenReady().then(() => {
  const distRoot = path.resolve(__dirname, '../dist');
  protocol.handle('aether', (request) => {
    const requestUrl = new URL(request.url);
    const relativePath = decodeURIComponent(requestUrl.pathname).replace(/^\/+/, '') || 'index.html';
    const resolvedPath = path.resolve(distRoot, relativePath);
    if (!resolvedPath.startsWith(`${distRoot}${path.sep}`) && resolvedPath !== distRoot) {
      return new Response('Blocked', { status: 403 });
    }
    return net.fetch(pathToFileURL(resolvedPath).toString());
  });
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(permission === 'media');
  });
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => permission === 'media');
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

ipcMain.handle('window:minimize', () => mainWindow?.minimize());
ipcMain.handle('window:close', () => mainWindow?.close());
ipcMain.handle('window:fullscreen', () => {
  if (!mainWindow) return false;
  mainWindow.setFullScreen(!mainWindow.isFullScreen());
  return mainWindow.isFullScreen();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
